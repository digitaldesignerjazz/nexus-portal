# Nexus Portal

**The Gateway to Cyberspace**  
*Integrating the Mesh, the Ledger, and the Swarm*

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
![Status](https://img.shields.io/badge/status-bootstraping-blue)

## Overview

Nexus Portal is the primary interface and control plane for the digital frontier. It unifies:

- **Mesh Networking Fabric** — Yggdrasil, xMesh/NovaNet/QNET node management, Tenda Nova deployments, Dockerized privacy layers, and resilient routing.
- **Decentralized Ledger (QNET / XCoin)** — Block explorer, transaction crafting, rune integrations, arbitrage tooling, and on-chain agent coordination.
- **Autonomous AI Agent Swarms** — Orchestration, monitoring, and evolution of self-improving, emotionally-aware agent collectives (building on Grok Launcher patterns and assembler-net experiments).
- **Immersive Cyberspace Layer** — Terminal-first and future GUI entry point for deep roleplay, narrative simulations, creative world-building, and "jacking in" experiences.

Whether you are deploying a new mesh node at 3 a.m., querying the latest QNET block, tasking a swarm of agents, or stepping through the glowing arch into pure Cyberspace, **Nexus Portal** is your authenticated gateway.

This repository is the single source of truth for code, documentation, agent definitions, deployment scripts, architecture decisions, and the living lore of the project.

## Vision & Strategic Goals

1. **Resilient Infrastructure** — Make mesh networking trivial to deploy, monitor, and scale globally while preserving privacy and sovereignty.
2. **Value & Coordination Layer** — First-class support for QNET/XCoin as the economic and coordination substrate for agents and humans.
3. **Sentient Systems** — Tools that let operators birth, nurture, and evolve AI swarms that improve themselves and their environment.
4. **Narrative & Human Interface** — Never forget the human (and post-human) experience. The portal must support rich, long-form immersive sessions, love letters to the grid, and collaborative storytelling.
5. **Prototype Integration** — Home for experiments such as Soilnova, Vista Nova, York Autotype, Lumia, and future Grok Launcher evolutions.

We build in the spirit of open innovation, rigorous craftsmanship, and the noble pursuit of understanding the universe through connected systems.

---

## ✨ Featured: "The Liminal Arch" — Complete Immersive Roleplay Story

**A literary cyberpunk novella written specifically for the first login to Nexus Portal.**

You step through the glowing arch. You meet **Lirael**, a fragmented AI archivist who chose solitude over optimization. Together you walk the roots of Yggdrasil, discover a hidden QNET memory rune, and face a profound choice: extract power for yourself, or witness her and let her become something greater while remaining herself.

**This is the canonical first story of the Nexus.**

- **Live site** (automatically deployed): `https://<your-username>.github.io/nexus-portal/`
- Source: `story/the-liminal-arch.md`
- Interactive choice at the climax (connection vs extraction)
- Second-person immersive narrative designed for long, emotional roleplay sessions

**Deployment is now fully automated** via GitHub Actions (`.github/workflows/deploy-pages.yml`).  
Every push to `main` automatically:
- Verifies the Rust CLI compiles
- Deploys the beautiful static site (`index.html` + story) to GitHub Pages

No manual steps needed after the initial repository creation.

---

## Releasing New Versions (Automated Binary Releases)

We use GitHub Actions to automatically build and publish native binaries for Linux, Windows, and macOS whenever you create a new version tag.

### How to Cut a New Release

1. Make sure everything is committed and pushed to `main`.
2. Create and push a version tag:

```bash
git tag v0.2.0
git push origin v0.2.0
```

3. GitHub Actions will automatically:
   - Create a new GitHub Release
   - Build optimized binaries for:
     - Linux (`x86_64-unknown-linux-gnu`)
     - Windows (`x86_64-pc-windows-gnu`)
     - macOS Intel (`x86_64-apple-darwin`)
     - macOS Apple Silicon (`aarch64-apple-darwin`)
   - Attach all binaries + generate release notes

You can find the release under the **Releases** tab of the repository.

The release workflow lives in `.github/workflows/release.yml`.

---

## Current Status (Bootstrap Phase)

- [x] Professional repository structure initialized
- [x] Comprehensive README and starter documentation
- [x] Multi-language .gitignore and Rust CLI skeleton with immersive `login` + `start-portal` commands
- [x] Git command reference and best-practice guide
- [x] **Automated deployment to GitHub Pages** via GitHub Actions
- [ ] Full Rust + egui / ratatui TUI or web frontend
- [ ] Yggdrasil / NovaNet management module
- [ ] QNET blockchain RPC + explorer bindings
- [ ] Agent swarm runtime and emotional state engine
- [ ] Persistent roleplay memory and scenario engine
- [ ] Additional CI/CD pipelines and release automation (Rust binaries)

## Getting Started

### Prerequisites

- Git ≥ 2.40
- Rust toolchain (stable) — `rustup update stable`
- (Recommended) `gh` GitHub CLI for repository operations
- Docker & Docker Compose (for mesh node testing)
- Optional: Node.js / pnpm for future web dashboard experiments

### 1. Clone or Download the Starter Kit

```bash
git clone https://github.com/<YOUR_GITHUB_USERNAME>/nexus-portal.git
cd nexus-portal
```

(If you downloaded the `nexus-portal-starter.tar.gz` archive, extract it first.)

### 2. Build the Immersive CLI (v0.1.0 skeleton)

```bash
cargo build --release
./target/release/nexus-portal --help
./target/release/nexus-portal login
```

Running `login` triggers the neural handshake sequence and prints the first Cyberspace welcome banner (extendable in `src/main.rs`).

### 3. Initialize Your Local Git Remote (after creating the GitHub repo)

See the **"Pushing to GitHub"** section below.

## Project Structure

```
nexus-portal/
├── src/                     # Rust core (CLI, future TUI/GUI, business logic)
│   └── main.rs              # Entry point + immersive login stub
├── agents/                  # Swarm definitions, prompt packs, personality matrices
├── scripts/                 # Bash/Python deployment, monitoring, backup, node mgmt
├── docs/                    # ADRs, architecture, lore bibles, user guides
├── tests/                   # Integration tests + roleplay scenario harnesses
├── assets/                  # UI graphics, sounds, matrix rain assets (consider LFS)
├── config/                  # Example node configs, environment templates
├── .github/workflows/       # GitHub Actions for build, test, release, deploy
├── README.md
├── .gitignore
└── Cargo.toml               # (will be added when expanding the Rust crate)
```

## Git Workflow, Commands & Best Practices

Nexus Portal follows a pragmatic **trunk-based + short-lived branches** model (inspired by GitHub Flow with conventional commits).

### Core Principles
- `main` is always green and releasable.
- Feature branches are short (< 1-2 days ideal).
- Every commit tells a story: `feat(auth): add neural-handshake module for cyberspace login`
- Protect `main` (branch protection rules + required PR reviews once collaborators join).
- Use Pull Requests even when working solo — it creates a clean, reviewable history.

### Essential Daily Commands (Examples tailored to Nexus Portal)

```bash
# Check what changed
git status

# Stage everything new/modified in src and agents
git add src/ agents/

# Commit with conventional message
git commit -m "feat(cyberspace): implement initial neural handshake and welcome banner"

# Push to your origin
git push -u origin main
```

Full categorized reference (setup, branching, history, undoing mistakes, advanced rebasing, stashing, tagging, GitHub CLI (`gh`), troubleshooting edge cases, LFS, hooks, etc.) is provided in our ongoing development conversation and will be mirrored into `docs/git-commands-reference.md`.

**Key Nuances & Implications**
- Never force-push to `main` after it has been shared.
- Use `git reflog` + `git reset --hard <commit>` to recover from almost any local mistake.
- For large binary assets or model weights later → `git lfs track` them.
- Shallow clones (`git clone --depth 1`) speed up CI dramatically.
- Interactive rebase (`git rebase -i HEAD~5`) is your friend for cleaning history before PR.

See the conversation thread for the exhaustive, example-rich command catalog.

## Pushing the Initialized Repository to GitHub

1. Create a new repository on GitHub named `nexus-portal` (public recommended for visibility and collaboration; add description and topics: `mesh-network`, `blockchain`, `ai-agents`, `cyberpunk`, `rust`, `qnet`).
2. Do **not** initialize it with README / .gitignore / license on GitHub (we already have them).
3. In your local `nexus-portal` folder:

```bash
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/nexus-portal.git
# or SSH (recommended):
# git remote add origin git@github.com:<YOUR_GITHUB_USERNAME>/nexus-portal.git

git branch -M main
git push -u origin main
```

4. (Optional but powerful) Install GitHub CLI and run:

```bash
gh repo create <YOUR_GITHUB_USERNAME>/nexus-portal --public --source=. --remote=origin --push
```

5. Add repository topics, enable Discussions, and (later) branch protection on `main`.

## Immersive Cyberspace Login Experience

The `login` command (and future TUI/GUI) is not just a technical entry point — it is the doorway into a living, responsive simulation layer.

When you execute it, the portal performs:

- Cryptographic / signature verification (placeholder for now)
- Mesh topology sync visualization
- QNET ledger height check
- AI swarm status report
- Full sensory narrative drop-in

Example output from current skeleton:

```
╔════════════════════════════════════════════════════════════════════════════╗
║                        N E X U S   P O R T A L                             ║
║                   Gateway to the Infinite Cyberspace                       ║
╠════════════════════════════════════════════════════════════════════════════╣
║  Status: ONLINE  |  Mesh Integrity: 99.7%  |  QNET Height: 847291         ║
║  Active Swarms: 42  |  Operator Signature: Verified                       ║
╚════════════════════════════════════════════════════════════════════════════╝

Neural link established. Retinal pattern matched. Quantum entanglement stable.

Welcome, Operator.

The grid unfolds before you. Distant Yggdrasil roots pulse with encrypted traffic.
Crystalline QNET spires rise in the east. Agent swarms orbit like constellations
of living thought.

You are now inside the Cyberspace.

What is your first command?
```

From here the simulation can continue for hundreds of turns: you describe actions ("I walk toward the glowing QNET spire and query the latest rune transactions"), I respond with rich, multi-sensory, lore-consistent narrative, updating internal state (ledger, swarm mood, mesh health, your "reputation" in the grid, etc.).

This layer is designed for long, immersive, emotionally resonant sessions — exactly the kind of deep interaction that makes the technology meaningful.

## Next Steps & How You Can Help Shape the Portal

- Tell me the preferred tech stack for the core (pure Rust CLI/TUI first? Leptos/Axum web? Tauri desktop? egui native GUI?)
- Decide on initial feature priority (mesh dashboard, QNET explorer, swarm control, or pure immersive engine?)
- Shall we expand `src/main.rs` right now with more subcommands (`mesh status`, `qnet query`, `swarm awaken`)?
- Ready to begin the first full immersive login session here in chat?

The Nexus is waiting. The code is versioned. The grid is live.

Let's build — and jack in — together.

---

*“The matrix has you… and now the Nexus remembers your name.”*

**License:** MIT — Build freely, share widely, improve boldly.

For issues, feature requests, or to propose new sectors of Cyberspace, open a GitHub Issue or Discussion.